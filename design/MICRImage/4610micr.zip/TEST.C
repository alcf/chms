/****************************************************************************

 COPYRIGHT 1996 IBM Corporation / Samplex Technologies, Inc.

 FILE NAME:     test.c

 DESCRIPTION:   Test driver for PARSER

 CHANGE HISTORY: 
     
     11-13-97 - removed the reversing of the MICR line

   
****************************************************************************/
#include    <stdio.h>
#include    <string.h>
#include    <ctype.h>
#include    <stdlib.h>

#include    "parse.h"

/* ---- Externals (Globals and Prototypes) ------------------------------- */

/* ---- Globals ---------------------------------------------------------- */

char            line[512];
char            *truth;
PARSER_STATUS   gold;

char    *ExToTxt[] =
    {
    "EX_NORMAL",
    "EX_USED",
    "EX_OPEN_ERR",
    "EX_INVALID"
    };

/* ---- Defines ---------------------------------------------------------- */

/* ---- Local Prototypes ------------------------------------------------- */
main(int argc, char *argv[]);
void    DumpElement(char *txt, char *contents, char status);
void    DumpBoth(char *txt, char *contents, char status, char *gold_contents, char gold_status);
char    *ExtractGoldField(char *dest, char *src);
char    *GrabGoldStatus(char *pstatus, char *psrc);
char    *GrabGoldString(char *pdest, char *psrc);
/* ---- Local Prototypes End --------------------------------------------- */

/****************************************************************************

 PUBLIC FUNCTION 
    main()

 DESCRIPTION:
    driver 
    - takes a single filename argument
    - results written to standard output        

 RETURN:
   
****************************************************************************/
main(int argc, char *argv[])
    {
    FILE            *instream;
    PARSER_STATUS   *ps;
    char            fname[80];
    char            *p;
    char            *micr;
    char            *exception;
    char            *bank;
    char            *fmt33;
    int             returncode = 0;


    if (argc < 2)
        {
        printf("Must give an input filename\n");
        exit(1);
        }
    else 
        strcpy(fname, argv[1]);

    /*
    **  Read each line, parse it, and dump the results
    */
    instream = fopen(fname, "rt");
    if (instream == NULL)
        {
        printf("Error opening input file (%s)\n", fname);
        exit(1);
        }

    while (fgets(line, sizeof(line), instream))
        {
        if (line[0] == 0)
            break;
        if (feof(instream))
            break;

        if (strchr(line, '\n'))
            *strchr(line, '\n') = '\0';

        if ((line[0] == 0) || (line[0] == '#'))
            continue;

        /*
        **  Break out the information into fields
        */
        exception = line;
        micr = strchr(line, ',');
        *micr = 0;
        micr++;
        bank = strchr(micr, ',');
        *bank = 0;
        bank++;
        truth = strchr(bank, ',');
        *truth = 0;
        truth++;

        /*
        **  Parse out the gold file info into a PARSER_STATUS structure
        */
        truth = GrabGoldStatus(&gold.status, truth);
        truth = GrabGoldString(gold.amount, truth);
        truth = GrabGoldStatus(&gold.amount_status, truth);
        truth = GrabGoldString(gold.tpc, truth);
        truth = GrabGoldStatus(&gold.tpc_status, truth);
        truth = GrabGoldString(gold.csn, truth);
        truth = GrabGoldStatus(&gold.csn_status, truth);
        truth = GrabGoldString(gold.account, truth);
        truth = GrabGoldStatus(&gold.account_status, truth);
        truth = GrabGoldString(gold.epc, truth);
        truth = GrabGoldStatus(&gold.epc_status, truth);
        truth = GrabGoldString(gold.onus, truth);
        truth = GrabGoldStatus(&gold.onus_status, truth);
        truth = GrabGoldString(gold.auxonus, truth);
        truth = GrabGoldStatus(&gold.auxonus_status, truth);
        truth = GrabGoldString(gold.transit, truth);
        truth = GrabGoldStatus(&gold.transit_status, truth);


 //     strrev(micr);     // reversing is done in ParseMicr()

        ps = ParseMicr(micr);

        /*
        **  Dump the results
        */
        printf("---------------------------------------------------------\n");
        printf("MICR line: %s\n", strrev(micr));
        printf("---------------------------------------------------------\n");
        printf(" Exception:        %-3s  %s\n", exception, bank);
        printf(" exception_state:  %s\n", ExToTxt[ps->exception_state]);
        printf(" status: %d", ps->status);
        printf(" unrecognized_symbols: %d\n", ps->unrecognized_symbols);
        DumpBoth(" amount:", ps->amount,   ps->amount_status,
                             gold.amount,  gold.amount_status);
        DumpBoth("account:", ps->account,  ps->account_status,
                             gold.account, gold.account_status);
        DumpBoth("    tpc:", ps->tpc,      ps->tpc_status,
                             gold.tpc,     gold.tpc_status);
        DumpBoth("    csn:", ps->csn,      ps->csn_status,
                             gold.csn,     gold.csn_status);
        DumpBoth("transit:", ps->transit,  ps->transit_status,
                             gold.transit, gold.transit_status);
        DumpBoth("    epc:", ps->epc,      ps->epc_status,
                             gold.epc,     gold.epc_status);
        DumpBoth("   onus:", ps->onus,     ps->onus_status,
                             gold.onus,    gold.onus_status);
        DumpBoth("auxonus:", ps->auxonus,  ps->auxonus_status,
                             gold.auxonus, gold.auxonus_status);
        printf("\n");     
        }                 
    }                    
                         
                        
void    DumpElement(char *txt, char *contents, char status)
    {                  
    printf("%10s", txt);
    switch (status)
        {
        case FIELD_OK:
            printf("  OK      [%s]\n", contents);
            break;
        case FIELD_INVALID:
            printf("  INVALID [%s]\n", contents);
            break;
        case FIELD_MISSING:
            printf("  MISSING [%s]\n", contents);
            break;
        default:
            printf("  UNKNOWN [%s]\n", contents);
            break;
        }
    }

char    *status_to_txt[] =
    {
    "OK     ",
    "INVALID",
    "MISSING",
    "TOOLONG",
    "UNRECOG",
    "NOTERM ",
    "???????",
    };

void    DumpBoth(char *txt, char *contents, char status, char *gold_contents, char gold_status)
    {
    char    sval;
    char    cmpval;

    sval = (status == gold_status);
    cmpval = (strcmp(contents, gold_contents) == 0);


    printf("%c%10s", (sval && cmpval) ? ' ' : '*', txt);

    if (status > FIELD_NOTERM)
        status = FIELD_NOTERM+1;
    if (gold_status > 2)
        gold_status = 3;

    if (!(sval && cmpval))
        printf(" %s %-25.25s    %s %-25.25s\n", 
                    status_to_txt[status],      contents,
                    status_to_txt[gold_status], gold_contents);
    else
        printf(" %s %-25.25s\n", 
                    status_to_txt[status],      contents);
    }


char    *ExtractGoldField(char *dest, char *src)
    {
    while (*src != ';')
        *dest++ = *src++;
    return ++src;
    }


char    xlate_status[] =
    {
    FIELD_INVALID,                  /*  */
    FIELD_MISSING,                  /* UNKNOWN */
    FIELD_OK,                       /* VALID */
    FIELD_INVALID,                  /*  */
    FIELD_INVALID,                  /* INVALID */
    };


char    *GrabGoldStatus(char *pstatus, char *psrc)
    {
    *pstatus = (char)atoi(psrc);
    return (psrc+2);
    }
char    *GrabGoldString(char *pdest, char *psrc)
    {
    while (*psrc != ',')
        *pdest++ = *psrc++;
    psrc++;
    *pdest = 0;
    return (psrc);
    }

