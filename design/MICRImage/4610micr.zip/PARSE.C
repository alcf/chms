/****************************************************************************

 COPYRIGHT 1996 IBM Corporation / Samplex Technologies, Inc.

 FILE NAME:     parse.c

 DESCRIPTION:   Check Parser

 CHANGE HISTORY:
 
 11-13-97:
	a. changed the Transit/OnUs/Amount/Dash/CMVC characters from
	   toadABCDE to TA$-abcde, respectively.  Also changed to reverse
	   the characters in the MICR line (reversed back before return).

 1-20-97:
	a. in Strip(), added check for NULL pointer argument
	b. in ParseONUS(), ll 559-571, replaced calls to strlen() by calls to nstrlen
	c. in DigitCount(), added test for NULL pointer argument
	d. changed char ExceptionProcess() into void ExceptionProcess()
		
   
****************************************************************************/

#include    <stdio.h>
#include    <ctype.h>
#include    <stdlib.h>
#include    <string.h>

#include    "parse.h"

/* ---- Externals (Globals and Prototypes) ------------------------------- */

/* ---- Globals ---------------------------------------------------------- */

PARSER_STATUS   ps;

/* ---- Defines ---------------------------------------------------------- */
#define ALWAYS_REREAD_EXCEPTIONS    0

typedef struct
    {
    char    type;                   /* type: P-ersonal or B-usiness */
    char    transit[10];            /* The transit number */
    char    field;                  /* Field number in which to look */
    char    spaces;                 /* A-sis or D-elete */
    char    skip;                   /* Number of characters to Skip */
    char    size;                   /* Size of sequence number */
    char    acc_rl;                 /* Account on R-ight or L-eft */
    } EXCEPTION;

/* ---- Local Statics ---------------------------------------------------- */
static EXCEPTION    ex;
static char         *cursor;

/* ---- Local Prototypes ------------------------------------------------- */
PARSER_STATUS   *ParseMicr (char *RawMicrLine);
PARSER_STATUS   *ParseCMC7(char *RawMicrLine);
static char ExtractField(char *dest, char *valid_syms, char len, char terminator);
static void ParseONUS(void);
static void SetField(char *src, char *dest, char *status);
static void InitParserStatus(void);
static void ReverseFields(void);
static int  nstrlen(char *str);
static int  DigitCount(char *str);
static void Strip(char *src);
static void ExceptionProcess(void);
static int  ScanExceptionsReread(void);
static void ValidateTransit(void);
/* ---- Local Prototypes End --------------------------------------------- */


/****************************************************************************

 PUBLIC FUNCTION 
    ParseMicr()

 DESCRIPTION:
    Public interface to parser.  Input MICR line is from left to right.   

 RETURN:
   
****************************************************************************/
PARSER_STATUS   *ParseMicr (char *RawMicrLine)
    {
    char    state;
    char    status;
    char    *p, *q;

    /*
    **  Initialize for new parsing operation and reverse the MICR line so it
    **  is from right to left (it will be "un-reversed" in ReverseFields())
    */
    InitParserStatus();
    cursor = RawMicrLine;

    strrev(cursor);

    /*
    **  First, check for unrecognized symbols
    */
    if (strchr(cursor, '?'))
	{
	ps.unrecognized_symbols = 1;
	}

    /*
    **  If there is even a single CMC7 separator, parse as CMC7
    */
    for (q = cursor; *q; q++)
	{
	if (strchr("abcde", *q))
	    return (ParseCMC7(cursor));
	}

    /*
    **  If we start with an AMT, then there is an amount field
    */
    if (*cursor == '$')
	{
	/*
	**  Amount field must contain 10 digits and must terminate
	**  with another AMT
	*/
	cursor++;                   /* move past opening AMT */
	status = ExtractField(ps.amount, "0123456789", AMT_LEN, '$');
	ps.amount_status = status;
	if (status != FIELD_OK)
	    goto parser_fail;
	cursor++;                   /* move past closing AMT */
	}

    /*
    **  Next is the ONUS field
    **  It may contain ONUS symbols as well as DASHes and SPACES
    **  Terminates with a TRANSIT
    **  This extraction includes any leading ONUS and trailing spaces
    **  ...but no leading spaces
    */
    while (*cursor && (*cursor == ' '))
	cursor++;

    if (!*cursor)
	goto parser_fail;

    status = ExtractField(ps.onus, "0123456789A- ", ONUS_LEN, 'T');
    ps.onus_status = status;
    if (status != FIELD_OK)
	goto parser_fail;

    /*
    **  Now for the TRANSIT field.  It contains digits only
    **  CANADIAN and OLD US checks contain a DASH as well
    */
    cursor++;                       /* move past opening transit */
    status = ExtractField(ps.transit, "0123456789-", TRN_LEN, 'T');
    ps.transit_status = status;
    if (status != FIELD_OK)
	goto parser_fail;
    ValidateTransit();
    cursor++;                       /* move past closing transit */

    /*
    **  Beyond this point are the optional EPC and AUX ONUS fields
    */

    /*
    **  If there is a EPC field, it is a single digit, before any
    **  ONUS field
    */
    while (*cursor && (*cursor == ' '))
	cursor++;
    if (*cursor)
	{
	/*
	**  Check for EPC
	*/
	if (isdigit(*cursor))
	    {
	    ps.epc_status = FIELD_OK;
	    ps.epc[0] = *cursor++;
	    ps.epc[1] = 0;
	    }

	/*
	**  Delete leading spaces and check for AUX ONUS
	*/
	while (*cursor && (*cursor == ' '))
	    cursor++;

	if (*cursor)
	    {
	    if (*cursor == 'A')
		{
		cursor++;
		status = ExtractField(ps.auxonus, "0123456789- ", AXON_LEN, 'A');
		ps.auxonus_status = status;
		if (status != FIELD_OK)
		    goto parser_fail;
		cursor++;                       /* move past onus */
		}
	    else
		{
		ps.auxonus_status = FIELD_INVALID;
		goto parser_fail;
		}
	    }
	}

    /*
    **  Initial parsing complete, time to parse the ONUS field(s)
    */
    if (ps.onus_status == FIELD_OK)
	ExceptionProcess();

    /*
    **  Not an exception, parse the ONUS in the usualy manner
    */
    if (ps.exception_state == EX_NORMAL)
	ParseONUS();

    /*
    **  Clean up ONUS...strip any leading ONUS symbols
    **  ...then strip any newly formed leading spaces
    */
    if (ps.onus[0] == 'A')
	strcpy(ps.onus, &ps.onus[1]);
    Strip(ps.onus);        

    /*
    **  Parsing operation complete and successful
    */
    ps.status = PASS;
    ReverseFields();
    return &ps;

 parser_fail:
    ps.status = FAIL;
    ReverseFields();
    return &ps;

    }

/****************************************************************************

 PUBLIC FUNCTION 
    ParseCMC7()

 DESCRIPTION:
    CMC7 parser for the 2 known FRENCH check formats
	(NOTE: CMC7 separators are a,b,c,d,e)

	Bank-issued checks:
	    Check number, Bank number, Account number 
		Leading separator is 'a', opens account number
		Next separator is 'e', opens bank number
		Next separator is 'c', closes bank number
		Next field is check number (no leading separator)
		Final separator is 'c', closes check number
		    ps.account filled with account number
		    ps.transit filled with bank number
		    ps.csn     filled with check number

	Postal-issued checks:
	    Check number and Postal/Bank number 
		Leading separator is 'c', precedes check number
		Next separator is 'd', opens bank number
		Next separator is 'd', closes bank number
		    ps.transit filled with bank number
		    ps.csn     filled with check number

 RETURN:
    Pointer to parser status, just like the ParseMicr public interface
   
****************************************************************************/
PARSER_STATUS   *ParseCMC7(char *RawMicrLine)
    {
    char    status;

    /*
    **  If it starts with a 'c', it's a postal check
    */
    if (*cursor == 'c')
	{
	/*
	**  First is check sequence number
	*/
	cursor++;                   /* move past 'c' */
	status = ExtractField(ps.csn, "0123456789", CSN_LEN, 'd');
	ps.csn_status = status;
	if (status != FIELD_OK)
	    goto parser_fail;

	/*
	**  Next is bank number
	*/
	cursor++;                   /* move past 'd' */
	while (*cursor && (*cursor == ' ')) /* strip leading spaces */
	    cursor++;
	status = ExtractField(ps.transit, "0123456789", CMC7BANK_LEN, 'd');
	ps.transit_status = status;
	if (status != FIELD_OK)
	    goto parser_fail;

	/*
	**  Should be nothing else
	*/
	cursor++;
	if (*cursor)
	    goto parser_fail;

	}
    /*
    **  If it starts with a 'a', it's a bank check
    */
    else if (*cursor == 'a')
	{
	/*
	**  First is account number
	*/
	cursor++;                   /* move past 'a' */
	status = ExtractField(ps.account, "0123456789 ", ACC_LEN, 'e');
	ps.account_status = status;
	if (status != FIELD_OK)
	    goto parser_fail;
	Strip(ps.account);

	/*
	**  Next is bank number
	*/
	cursor++;                   /* move past 'e' */
	while (*cursor && (*cursor == ' ')) /* strip leading spaces */
	    cursor++;
	status = ExtractField(ps.transit, "0123456789", CMC7BANK_LEN, 'c');
	ps.transit_status = status;
	if (status != FIELD_OK)
	    goto parser_fail;

	/*
	**  Next is check sequence number
	*/
	cursor++;                   /* move past 'c' */
	while (*cursor && (*cursor == ' ')) /* strip leading spaces */
	    cursor++;
	status = ExtractField(ps.csn, "0123456789", CSN_LEN, 'c');
	ps.csn_status = status;
	if (status != FIELD_OK)
	    goto parser_fail;

	/*
	**  Should be nothing else
	*/
	cursor++;
	if (*cursor)
	    goto parser_fail;

	}
    /*
    **  Otherwise, it's completely bogus
    */
    else
	goto parser_fail;

    /*
    **  Parsing operation complete and successful
    */
    ps.status = PASS;
    ReverseFields();
    return &ps;

 parser_fail:
    ps.status = FAIL;
    ReverseFields();
    return &ps;

    }


/****************************************************************************

 LOCAL FUNCTION 
    ExtractField()

 DESCRIPTION:
    Given a list of valid symbols, a max size and a terminator, 
    extract a field starting at "cursor".
    The extracted field will NOT include the terminator.
    trailing SPACES are deleted

 RETURN:
    "cursor" updated to point to terminator
    status code:
	FIELD_OK        No errors
	MISSING         Terminator was first character
	TOOLONG         Field did not fit in max length
	FIELD_INVALID   Invalid symbol within field (but term correctly)
	UNRECOG_SYMS    Unrecognized symbol within field (but term correctly)
	NO_TERMINATOR   Terminator not found (premature end of string)

****************************************************************************/
static char ExtractField(char *dest, char *valid_syms, char len, char terminator)
    {
    char    status;
    char    sym;
    char    field[MAX_FIELD_LEN+1];
    char    cnt;
    char    j;
    char    *start;

    status = FIELD_OK;

    /*
    **  Extract characters up to the terminator or max length
    **  Terminate local copy of field with a NULL
    */
    for(cnt = 0, start = dest; ; cnt++)
	{
	if (!*cursor)
	    {
	    status = FIELD_NOTERM;
	    break;
	    }
	if (*cursor == terminator)
	    break;
	*dest++ = *cursor++;
	if (--len < 0)
	    {
	    status = FIELD_TOOLONG;
	    break;
	    }
	}
    *dest = 0;

    /*
    **  Check for missing field
    */
    if (cnt == 0)
	status = FIELD_MISSING;

    /*
    **  If no errors yet, check for validity
    */
    if (status == FIELD_OK)
	{
	/*
	**  Validate that all characters are valid
	*/
	for (j = 0; j < cnt; j++)
	    {
	    if (start[j] == '?')
		{
		status = FIELD_UNRECOG;
		break;
		}
	    if (!strchr(valid_syms, start[j]))
		{
		status = FIELD_INVALID;
		break;
		}
	    }
	}

    Strip(dest);
    return status;
    }

/****************************************************************************

 LOCAL FUNCTION 
    ParseONUS()

 DESCRIPTION:
    determine TPC, Account and Sequence number from ONUS and AUX ONUS fields

 RETURN:
    ps updated

****************************************************************************/
static void ParseONUS()
    {
    static char    onus[ONUS_LEN];
    static char    _onus[ONUS_LEN];
    static char    temp[ONUS_LEN];

    char    *p;
    char    *segA, *segB, *segC;    /* Point to segments */

    char    _segA[ONUS_LEN], _segB[ONUS_LEN], _segC[ONUS_LEN];

    char    *subA1, *subA2, *subA3, /* Point to subfields */
	    *subB1, *subB2, *subB3, *subBL,
	    *subC1, *subC2, *subC3;

    char    lenA1, lenA2, lenA3,    /* Associated lengths */
	    lenB1, lenB2, lenB3, lenBL,
	    lenC1, lenC2, lenC3;

    char    lenA,  lenB,  lenC;

    subA1 = subA2 = subA3 = 
    subB1 = subB2 = subB3 = subBL =
    subC1 = subC2 = subC3 = NULL;

    /*
    **  Make a local working copy of the ONUS field
    */
    Strip(ps.onus);                 /* Strip leading and trailing spaces */
    strcpy(onus, ps.onus);
    strcpy(_onus, ps.onus);         /* This will be destroyed */

    /*
    **  Split up the ONUS into segments separated by ONUS symbols
    **  Note: segA contains only symbols PRIOR to the first ONUS sym
    */
    if (_onus[0] != 'A')
	{
	if (segA = strtok(_onus, "A"))
	    if (segB = strtok(NULL, "A"))
		segC = strtok(NULL, "A");
	}
    else
	{
	segA = NULL;
	if (segB = strtok(_onus, "A"))
	    segC = strtok(NULL, "A");
	}
    Strip(segA);
    Strip(segB);
    Strip(segC);

    /*
    **  Build copies of first, second and last subfields
    **  ...separated by Space or Dash
    */
    if (segA)
	{
	strcpy(_segA, segA);
	if (subA1 = strtok(_segA, " -"))
	    if (subA2 = strtok(NULL, " -"))
		subA3 = strtok(NULL, " -");
	}
    if (segB)
	{
	strcpy(_segB, segB);
	if (subB1 = strtok(_segB, " -"))
	    if (subB2 = strtok(NULL, " -"))
		if(subBL = strtok(NULL, " -"))
		    {
		    /* ...Find leftmost subfield */
		    do
			{
			subB3 = subBL;
			} while (subBL = strtok(NULL, " -"));
		    subBL = subB3;
		    }
	}
    if (segC)
	{
	strcpy(_segC, segC);
	if (subC1 = strtok(_segC, " -"))
	    if (subC2 = strtok(NULL, " -"))
		subC3 = strtok(NULL, " -");
	}

    /* ...build length variables too...for readability later */
    lenA1 = nstrlen(subA1);
    lenA2 = nstrlen(subA2);
    lenA3 = nstrlen(subA3);
    lenA  = DigitCount(segA);
    lenB1 = nstrlen(subB1);
    lenB2 = nstrlen(subB2);
    lenB3 = nstrlen(subB3);
    lenBL = nstrlen(subBL);
    lenB  = DigitCount(segB);
    lenC1 = nstrlen(subC1);
    lenC2 = nstrlen(subC2);
    lenC3 = nstrlen(subC3);
    lenC  = DigitCount(segC);

    /*
    **  Check segment A subfields for CSN and TPC
    */
    if (lenA1 && lenA2)
	{
	/*
	**  If two pieces in first segment
	*/
	if ((lenA1 > lenA2) && (lenA1 >= 3))
	    {
	    /*
	    **  First sub is longest, and at least 3 digits
	    */
	    SetField(subA1, ps.csn, &ps.csn_status);
	    SetField(subA2, ps.tpc, &ps.tpc_status);
	    }
	else if (lenA2 >= 3)
	    {
	    /*
	    **  Second sub is at least 3 digits
	    */
	    SetField(subA1, ps.tpc, &ps.tpc_status);
	    SetField(subA2, ps.csn, &ps.csn_status);
	    }
	}
    else if (lenA1 > 0)
	{
	if (strcmp(subA1, "100") == 0)
	    {
	    /*
	    **  Single sub of 001 is always the TPC 
	    **  (remember, strings are reversed at this point)
	    */
	    SetField(subA1, ps.tpc, &ps.tpc_status);
	    }
	else if (lenA1 >= 3)
	    {
	    /*
	    **  Otherwise, if it's at least 3 digits, it's the CSN
	    */
	    SetField(subA1, ps.csn, &ps.csn_status);
	    }
	else
	    {
	    /*
	    **  Shorter than 3 digits, it's a TPC
	    */
	    SetField(subA1, ps.tpc, &ps.tpc_status);
	    }
	}
    /*
    **  If CSN still unknown and there is an AUX ONUS, use it as the 
    **  sequence number
    **  The ONUS contains the account number (and maybe a TPC)
    */
    if ((ps.csn_status == FIELD_MISSING) && 
	(ps.auxonus_status == FIELD_OK))
	{
	SetField(ps.auxonus, ps.csn, &ps.csn_status);
	}
    /*
    **  Check remaining segments if the CSN is still unknown
    */
    if ((ps.csn_status == FIELD_MISSING) && (lenB1 || lenC1))
	{
	if (!lenC1)
	    {
	    /*
	    **  No subfields in segC, look for CSN in B segment
	    */
	    if (lenB1 && lenB2)
		{
		/*
		**  At least 2 subfields in segB
		**  CSN is leftmost if:
		**      3 or 4 digits, and at least 5 left over
		**      (remainder is ACCT)
		**  CSN is rightmost if:
		**      3 or 4 digits, and at least 5 left over
		**      (remainder is ACCT)
		**  Else
		**      segB is ACCT
		*/
		if ((lenBL == 0) && 
		    ((lenB2 == 3) || (lenB2 == 4)) && (lenB1 >= 5))
		    {
		    /* ...leftmost is subB2 */
		    SetField(subB2, ps.csn, &ps.csn_status);
		    SetField(subB1, ps.account, &ps.account_status);
		    }
		else if (((lenBL == 3) || (lenBL == 4)) && (lenB - lenBL >= 5))
		    {
		    /* ...leftmost is subBL */
		    SetField(subBL, ps.csn, &ps.csn_status);
		    strncpy(temp, segB, strlen(segB) - lenBL);
		    temp[strlen(segB) - lenBL] = 0; /* terminate it! */
		    /* ...trim trailing DASH and SPACE */
		    p = temp + strlen(temp) - 1;
		    while ((*p == ' ') || (*p == '-'))
			*p-- = 0;
		    SetField(temp, ps.account, &ps.account_status);
		    }
		else if (((lenB1 == 3) || (lenB1 == 4)) && (lenB - lenB1 >= 5))
		    {
		    /* ...try rightmost */
		    SetField(subB1, ps.csn, &ps.csn_status);
		    SetField(&segB[lenB1], ps.account, &ps.account_status);
		    }
		else
		    {
		    /* ...no CSN found, call it all the ACCOUNT */
		    SetField(segB, ps.account, &ps.account_status);
		    }
		}
	    else
		{
		/* ...only a single sub in segB - all account */
		SetField(subB1, ps.account, &ps.account_status);
		}
	    }
	else if (lenB1 && lenC1)
	    {
	    /*
	    **  We have a segC
	    **  If only a single sub in B and C, CSN is the shorter one
	    **  If only a single sub in B, subB1 is the CSN 
	    */
	    if ((lenB2 == 0) && (lenC2 == 0))
		{
		/* ...single sub in B and C, CSN is shorter */
		if (lenB1 > lenC1)
		    {
		    SetField(subC1, ps.csn, &ps.csn_status);
		    SetField(subB1, ps.account, &ps.account_status);
		    }
		else
		    {
		    SetField(subB1, ps.csn, &ps.csn_status);
		    SetField(subC1, ps.account, &ps.account_status);
		    }
		}
	    else if (lenB2 == 0)    /* lenC2 != 0 */
		{
		/* ...single sub in B, multiple in C: CSN is subB1 */
		SetField(subB1, ps.csn, &ps.csn_status);
		SetField(segC, ps.account, &ps.account_status);
		}
	    else if (lenC2 == 0)    /* lenB2 != 0 */
		{
		/* ...single sub in C, multiple in B: CSN is subC1 */
		SetField(subC1, ps.csn, &ps.csn_status);
		SetField(segB, ps.account, &ps.account_status);
		}
	    else
		{
		/* ...both B and C have multiple subs...guess! */
		SetField(segB, ps.account, &ps.account_status);
		}
	    }
	else    /* no B subs at all */
	    {
	    /* ...Acct is the entire segC field */
	    SetField(segC, ps.account, &ps.account_status);
	    }
	}
    else /* CSN is known OR no segB or segC*/
	{
	/* ...grab ACCT from segB or segC if they exist */
	if (lenB1)
	    {
	    SetField(segB, ps.account, &ps.account_status);
	    }
	else if (lenC1)
	    {
	    SetField(segC, ps.account, &ps.account_status);
	    }
	}
    /*
    **  Final cleanup on ACCOUNT (may have leading or trailing spaces)
    */
    Strip(ps.account);
    }

/****************************************************************************

 LOCAL FUNCTION 
    SetField()

 DESCRIPTION:
    set field contents and status flag

 RETURN:
    
****************************************************************************/
static void SetField(char *src, char *dest, char *status)
    {
    strcpy(dest, src);
    if (strchr(src, '?'))
	*status = FIELD_UNRECOG;
    else
	*status = FIELD_OK;
    }

/****************************************************************************

 LOCAL FUNCTION 
    InitParserStatus()

 DESCRIPTION:
    Initialize ps for new operation

 RETURN:
    none
    
****************************************************************************/
static void InitParserStatus()
    {
    ps.status                = PASS;
    ps.exception_state       = EX_NORMAL;
    ps.unrecognized_symbols  = 0;
    ps.amount_status         = FIELD_MISSING;
    *ps.amount               = 0;
    ps.account_status        = FIELD_MISSING;
    *ps.account              = 0;
    ps.tpc_status            = FIELD_MISSING;
    *ps.tpc                  = 0;
    ps.csn_status            = FIELD_MISSING;
    *ps.csn                  = 0;
    ps.transit_status        = FIELD_MISSING;
    *ps.transit              = 0;
    ps.epc_status            = FIELD_MISSING;
    *ps.epc                  = 0;
    ps.onus_status           = FIELD_MISSING;
    *ps.onus                 = 0;
    ps.auxonus_status        = FIELD_MISSING;
    *ps.auxonus              = 0;
    }

/****************************************************************************

 LOCAL FUNCTION 
    ReverseFields()

 DESCRIPTION:
    Reverse all the fields on the check (and the original input MICR line
    that was already reversed (i.e., return to its original state))

 RETURN:
    
****************************************************************************/
static void ReverseFields()
    {
    strrev(ps.amount);
    strrev(ps.account);     
    strrev(ps.tpc);
    strrev(ps.csn);
    strrev(ps.transit);
    strrev(ps.epc);
    strrev(ps.onus);        
    strrev(ps.auxonus);

    strrev(cursor);
    }

/****************************************************************************

 LOCAL FUNCTION 
    nstrlen()

 DESCRIPTION:
    Standard string length, but returns 0 if NULL string

 RETURN:
    int - length of string

****************************************************************************/
static int  nstrlen(char *str)
    {
    if (str == NULL)
	return 0;
    else
	return strlen(str);
    }

/****************************************************************************

 LOCAL FUNCTION 
    DigitCount()

 DESCRIPTION:
    Number of digits in string

 RETURN:
    int 

****************************************************************************/
static int  DigitCount(char *str)
{
    size_t  cnt = 0;

	if (str == NULL)
		return 0;

    while (*str)
    {
	if ((*str >= '0') && (*str <= '9'))
	    cnt++;
	str++;
    }
    return cnt;
}

/****************************************************************************

 LOCAL FUNCTION 
    Strip()

 DESCRIPTION:
    remove leading and trailing spaces

 RETURN:
    none
****************************************************************************/
static void Strip(char *src)
{
    char    *p;

	if (src != NULL)
	{
		if (*src)
		{
		p = src;
		p +=  strlen(p) - 1;
		while (*p == ' ')
			*p-- = 0;

		strrev(src);
		p = src;
		p +=  strlen(p) - 1;
		while (*p == ' ')
			*p-- = 0;

		strrev(src);
		}
	}
}

/****************************************************************************

 LOCAL FUNCTION 
    ExceptionProcess()

 DESCRIPTION:
    Try exception processing, keying on the TRANSIT field

 RETURN:
    exception status in ps.exception_state
    
****************************************************************************/
static void ExceptionProcess()
    {
    static char     onus[ONUS_LEN];
    static char     tpc[TPC_LEN];
    char            *field;
    char            *p, *q, *csn_start;
    char            cnt;

    /*
    **  Open exception file and look for matching transit field
    **  If found, exception record is returned
    */
    ps.exception_state = ScanExceptionsReread();

    /*
    **  Process exception
    **      Note: fields are still in reverse order
    */
    if (ps.exception_state == EX_USED)
	{
	/*
	**  Grab appropriate ONUS field
	*/
	strcpy(onus, ps.onus);      /* create working copy */
	Strip(onus);
	cnt = 0;
	if ((onus[0] == 'A') && (ex.field == 0))
	    {
	    field = "";
	    ps.tpc[0] = 0;
	    }
	else
	    {
	    if (onus[0] == 'A')
		cnt++;
	    field = strtok(onus, "A");
	    while (cnt != ex.field)
		{
		if ((cnt == 0) && (ex.field != 0))
		    strcpy(ps.tpc, field);
		field = strtok(NULL, "o");
		cnt++;
		}
	    }

	/*
	**  Delete spaces if requested
	*/
	if (ex.spaces == 'D')
	    {
	    for (q = p = field; *p; p++)
		{
		if (*p != ' ')
		    *q++ = *p;
		}
	    *q = 0;
	    }

	/*
	**  Skip to starting point for CSN 
	*/
	if (ex.skip > strlen(field))
	    csn_start = field+strlen(field);
	else
	    csn_start = field+ex.skip;

	/*
	**  Extract CSN
	*/
	q = ps.csn;
	cnt = ex.size;
	p = csn_start;
	while (*p && cnt)
	    {
	    *q++ = *p++;
	    cnt--;
	    }
	*q = 0;

	/*
	**  Extract ACCOUNT
	*/
	q = ps.account;
	if (ex.acc_rl == 'R')
	    {
	    /* ...Account on RIGHT means from the start up to the CSN */
	    p = field;
	    while (p != csn_start)
		*q++ = *p++;
	    }
	else
	    {
	    /* ...Account on LEFT means the rest of the field */
	    while (*p)
		*q++ = *p++;
	    }
	*q = 0;

	/*
	**  Update field status bytes
	*/
	if (strlen(ps.account))
	    ps.account_status = FIELD_OK;
	if (strlen(ps.csn))
	    ps.csn_status = FIELD_OK;
	if (strlen(ps.tpc))
	    ps.tpc_status = FIELD_OK;
	}
    }


/****************************************************************************

 LOCAL FUNCTION 
    ScanExceptionsReread()

 DESCRIPTION:
    if exception file not open yet,
	open exception file
	build internal database of exceptions
    search database of exceptions for matching entry
    set exception entry for caller
    return status code

 RETURN:
    
****************************************************************************/
static int  ScanExceptionsReread()
    {
    FILE        *ex_stream;
    char        line[256];
    char        *p;
    int         numfields;
    int         status;

    /*
    **  Open exceptions file
    */
    ex_stream = fopen("PARSE.DAT", "rt");
    if (ex_stream == NULL)
	return EX_OPEN_ERR;

    /*
    **  Read file one line at a time.
    **      lines starting with '#' are ignored
    **      empty lines are ignored
    **      all others must conform to the exception format (8 fields)
    */
    while (fgets(line, sizeof(line), ex_stream))
	{
	if (line[0] == 0)
	    break;

	if (feof(ex_stream))
	    break;

	if (strchr(line, '\n'))
	    *strchr(line, '\n') = '\0';

	Strip(line);

	if ((line[0] == 0) || (line[0] == '#'))
	    continue;

	/* ...force upper case */
	strupr(line);

	/*
	**  Extract fields
	*/
	numfields = 0;
	if (p = strtok(line, " "))
	    {
	    ex.type = *p;
	    numfields++;
	    if (p = strtok(NULL, " "))
		{
		strcpy(ex.transit, p);
		numfields++;
		if (p = strtok(NULL, " "))
		    {
		    ex.spaces = *p;
		    numfields++;
		    if (p = strtok(NULL, " "))
			{
			ex.field = (char)atoi(p);
			numfields++;
			if (p = strtok(NULL, " "))
			    {
			    ex.skip = (char)atoi(p);
			    numfields++;
			    if (p = strtok(NULL, " "))
				{
				ex.size = (char)atoi(p);
				numfields++;
				if (p = strtok(NULL, " "))
				    {
				    ex.acc_rl = *p;
				    numfields++;
				    }
				}
			    }
			}
		    }
		}
	    }

	/*
	**  Validate field contents
	*/
	if ((numfields != 7)           || 
	    (strlen(ex.transit) != 9)  ||
	    (!strchr("BP", ex.type))   || 
	    (!strchr("AD", ex.spaces)) ||
	    (!strchr("RL", ex.acc_rl)))
	    {
	    fclose(ex_stream);
	    return EX_INVALID;
	    }

	/*
	**  Does transit match?
	*/
	if (strcmp(ps.transit, strrev(ex.transit)) == 0)
	    {
	    fclose(ex_stream);
	    return EX_USED;
	    }
	}

    /*
    **  No exception match
    */
    fclose(ex_stream);
    return EX_NORMAL;
    }

/****************************************************************************

 LOCAL FUNCTION 
    ValidateTransit()

 DESCRIPTION:
    Confirm transit number, update parser status

 RETURN:
    none
    
****************************************************************************/
static void ValidateTransit()
    {
    char    *p;
    int     cnt;
    /*
    **  Count dashes in the transit
    */
    for (cnt = 0, p=ps.transit; *p; p++)
	{
	if (*p == '-')
	    cnt++;
	}
    /*
    **  Three forms allowed:
    **      Standard US - must be confirmed with checkdigit
    **      Old US - dash in position 4
    **      Canadian - dash in position 3
    */
    if (cnt > 1)
	{
	/*
	**  More than one DASH is an error
	*/
	ps.transit_status = FIELD_INVALID;
	}
    else if (cnt == 1)
	{
	/*
	**  Single DASH is either CAN or OLD US.  No checksum needed
	*/
	if (!((ps.transit[3] == '-') || (ps.transit[4] == '-')))
	    ps.transit_status = FIELD_INVALID;
	}
    else if ((( 
	   (3*((ps.transit[8]-'0')+
	       (ps.transit[5]-'0')+
	       (ps.transit[2]-'0')))+
	   (7*((ps.transit[7]-'0')+
	       (ps.transit[4]-'0')+
	       (ps.transit[1]-'0')))+
	       (ps.transit[6]-'0')+
	       (ps.transit[3]-'0')+
	       (ps.transit[0]-'0')) %10) != 0)
	{
	ps.transit_status = FIELD_INVALID;
	}
    return;
    }
